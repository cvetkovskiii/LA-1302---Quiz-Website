const loginC = require("./controller/00_LoginController");
const express = require("express");
const http = require("http");
const fs = require("fs");
const cors = require("cors");
const { fstat } = require("fs");
const jwt = require("jsonwebtoken");

var path = require("path");
const { response } = require("express");
const { options } = require("nodemon/lib/config");

const app = express();
const port = 3000;

app.use(express.json()); // for parsing application/json
app.use(express.urlencoded({ extended: true })); // for parsing application/x-www-form-urlencoded
app.use(cors());
app.listen(port, () => console.log(`API ist live on http://localhost:${port}`));

function auth(req, res) {
  try {
    const token = req.body.token;
    const jwtData = jwt.verify(token, "mySuperSecretKey");
    if (jwtData) {
      Authentication = true;
      return res.json({
        err: false,
        msg: "authorization complete",
      });
    }
  } catch (error) {
    Authentication = false;
    return res.json({
      err: true,
      msg: "authorization error",
    });
  }
}

app.use(express.static("../user/"));

app.post("/login", loginC.login);

// ====================== Zugangspunkte ====================================================

app.get("/info", (req, res) => {
  res.send({
    Author: "Elbish Bhusal",
    Name: "Lernatelier",
    Company: "Student",
  });
});

// ========================================= Login ===================================================

// ======================================== Start Server ======================================================
